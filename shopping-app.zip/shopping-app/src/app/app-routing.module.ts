import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { ProductsComponent } from './products/products.component';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { ModifyproductsComponent } from './modifyproducts/modifyproducts.component';
import { DeleteproductComponent } from './deleteproduct/deleteproduct.component';
import { HomeComponent } from './home/home.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { UpdateproductComponent } from './updateproduct/updateproduct.component';
import { CartComponent } from './cart/cart.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ViewcartComponent } from './viewcart/viewcart.component';
import { DeletecartComponent } from './deletecart/deletecart.component';

const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"signup", component:SignupComponent},
  {path:"login",component:LoginComponent},
  {path:"products",component:ProductsComponent},
  {path:"details/:productId",component:ProductdetailsComponent},
  {path:"modify",component:ModifyproductsComponent},
  {path:"delete/:productId",component:DeleteproductComponent},
  {path:"add",component:AddproductComponent},
  {path:"update/:productId",component:UpdateproductComponent},
  {path:"cart",component:CartComponent},
  {path:"viewCart",component:ViewcartComponent},
  {path:"deletecart/:cartItemId",component:DeletecartComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
