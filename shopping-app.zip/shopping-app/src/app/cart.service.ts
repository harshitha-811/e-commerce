import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CartItem } from './entity/cartitem';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private http:HttpClient) { }

  addCartItem(cartitem:CartItem):Observable<CartItem>{
    return this.http.post<CartItem>("http://localhost:8083/cartitem/add",cartitem);
  }
  viewCartByCustomerId(customerId:number):Observable<CartItem[]>{
    return this.http.get<CartItem[]>("http://localhost:8083/cartitem/items/"+customerId);
  }
  deleteCartItem(cartItemId:number):Observable<boolean>{
    return this.http.delete<boolean>("http://localhost:8083/cartitem/delete/"+cartItemId);
  }
  deleteAll():Observable<any>{
    return this.http.delete("http://localhost:8083/cartitem/deleteall");
  }
}
