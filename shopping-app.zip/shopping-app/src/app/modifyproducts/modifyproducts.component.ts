import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../entity/product';

@Component({
  selector: 'app-modifyproducts',
  templateUrl: './modifyproducts.component.html',
  styleUrls: ['./modifyproducts.component.css']
})
export class ModifyproductsComponent implements OnInit {

  constructor(private productService:ProductService) { }

  products:Product[]=[];
  ngOnInit(): void {
    this.productService.viewProduct().subscribe(m=>this.products=m);
  }

}
