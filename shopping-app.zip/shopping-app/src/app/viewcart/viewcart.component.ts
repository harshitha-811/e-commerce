import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { Router } from '@angular/router';
import { CartItem } from '../entity/cartitem';

@Component({
  selector: 'app-viewcart',
  templateUrl: './viewcart.component.html',
  styleUrls: ['./viewcart.component.css']
})
export class ViewcartComponent implements OnInit {

  constructor(private cartservice:CartService,private router:Router) { }
 
  cartItems:CartItem[];
  ngOnInit(): void {
    this.cartservice.viewCartByCustomerId(localStorage.customerId).subscribe(c=>{this.cartItems=c});
  }
 
  logout(){
    localStorage.removeItem('customerEmail');
    this.cartservice.deleteAll().subscribe();
    this.router.navigate(['']);
  }

}
