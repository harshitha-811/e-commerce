import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Product } from '../entity/product';
import { CustomerService } from '../customer.service';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  productForm:FormGroup;

  product:Product=new Product;

  message:string;

  constructor(private fb:FormBuilder, private productService:ProductService,private router:Router) { }
  
  ngOnInit(): void {
    this.initForm();
  }


  private initForm(){
    this.productForm=this.fb.group({
      productName:[,[Validators.required,Validators.minLength(3)]],
      description:[,[Validators.required]],
      price:[,Validators.required],
      imageUrl:[,[Validators.required]],  
    });
  }
  onSubmit(){
    console.log(this.productForm);
    this.product=this.productForm.value;
    this.productService.addProduct(this.product)
    .subscribe(m=>{
      if(m){
        this.router.navigate(['modify']);
      }
      this.message="The product already exists"
    })

  }
}
