import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from './entity/customer';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient) { }
  

  signup(customer:Customer):Observable<string>{
    return this.http.post<string>('http://localhost:8081/customers/signup',customer,{responseType:'text' as 'json'});
  }

  login(customer:Customer):Observable<Customer>{
    return this.http.post<Customer>('http://localhost:8081/customers/login',customer);
  }
  getCustByEmail(customerEmail:string):Observable<Customer>{
    return this.http.get<Customer>('http://localhost:8081/customers/'+customerEmail);
  }
}
