export class Customer{
    customerId:number;
    customerEmail:string;
    customerPassword:string;
}