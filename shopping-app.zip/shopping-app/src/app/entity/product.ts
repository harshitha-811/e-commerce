export class Product{
    productId:number;
    productName:string;
    description:string;
    price:number;
    imageUrl:string;
}