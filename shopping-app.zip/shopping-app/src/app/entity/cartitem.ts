export class CartItem{
    cartItemId:number;
    customerId:number;
    productId:number;
    quantity:number;
}