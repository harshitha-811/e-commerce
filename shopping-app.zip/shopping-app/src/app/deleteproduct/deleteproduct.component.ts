import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../entity/product';

@Component({
  selector: 'app-deleteproduct',
  templateUrl: './deleteproduct.component.html',
  styleUrls: ['./deleteproduct.component.css']
})
export class DeleteproductComponent implements OnInit {

  constructor(private productService:ProductService,
              private activatedRoute:ActivatedRoute,
              private router:Router) { }


  product:Product;
  isDeleted:Boolean=false;
  ngOnInit(): void {
    
    let productId=this.activatedRoute.snapshot.params['productId'];
    this.productService.deleteProduct(productId)
    .subscribe(data=>{
      this.isDeleted=data;
      if(this.isDeleted){
        this.router.navigate(['modify']);
      }
    })
    console.log(this.isDeleted);
  }

}
