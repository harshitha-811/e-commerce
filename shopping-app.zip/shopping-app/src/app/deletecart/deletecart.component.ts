import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-deletecart',
  templateUrl: './deletecart.component.html',
  styleUrls: ['./deletecart.component.css']
})
export class DeletecartComponent implements OnInit {

  constructor(private cartservice:CartService,private activatedroute:ActivatedRoute,private router:Router) { }
 
  ngOnInit(): void {
    let id=this.activatedroute.snapshot.params['cartItemId'];
    let isDeleted:boolean=false;
    this.cartservice.deleteCartItem(id).subscribe(data=>{
      isDeleted=data;
      if(isDeleted){
        this.router.navigate(['viewCart']);
      }
    })
  }

}
