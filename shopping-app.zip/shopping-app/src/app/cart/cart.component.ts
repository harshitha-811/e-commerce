import { Component, OnInit } from '@angular/core';
import { CartItem } from '../entity/cartitem';
import { CartService } from '../cart.service';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { Customer } from '../entity/customer';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartItem:CartItem=new CartItem;
  customer:Customer=new Customer();
  cartItems:CartItem[]=[];
  quantity:number=1;
  constructor(private cartService:CartService, private router:Router, private customerService:CustomerService) { }

  ngOnInit(): void {
    this.addToCart();
  }
  addToCart(){
    // let customerEmail=localStorage.getItem('customerEmail');
    // this.customerService.getCustByEmail(customerEmail).subscribe(m=>this.customer=m);
    // this.cartItem.customerId=this.customer.customerId;
    this.cartItem.customerId=parseInt(localStorage.getItem('customerId'))
    this.cartItem.productId=parseInt(localStorage.getItem('productId'));
    this.cartItem.quantity=this.quantity;
    this.cartService.addCartItem(this.cartItem).subscribe(c=>this.cartItem=c);
  }
  // removeFromCart(productId:number){
  //   this.cartService.viewCartByCustomerId(productId).subscribe(c=>this.cartItem=c);
  //   if(this.cartItem.quantity>1){
  //     this.cartItem.quantity--;
  //     this.cartservice.addToCart(this.cartItem).subscribe();
  //   }
  // }

}
