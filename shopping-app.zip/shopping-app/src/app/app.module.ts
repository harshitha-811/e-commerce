import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { CustomerService } from './customer.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from "@angular/common/http";
import { LoginComponent } from './login/login.component';
import { ProductsComponent } from './products/products.component';
import { ProductService } from './product.service';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { ModifyproductsComponent } from './modifyproducts/modifyproducts.component';
import { DeleteproductComponent } from './deleteproduct/deleteproduct.component';
import { HomeComponent } from './home/home.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { UpdateproductComponent } from './updateproduct/updateproduct.component';
import { CartComponent } from './cart/cart.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ViewcartComponent } from './viewcart/viewcart.component';
import { DeletecartComponent } from './deletecart/deletecart.component';

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    LoginComponent,
    ProductsComponent,
    ProductdetailsComponent,
    ModifyproductsComponent,
    DeleteproductComponent,
    HomeComponent,
    AddproductComponent,
    UpdateproductComponent,
    CartComponent,
    NavbarComponent,
    ViewcartComponent,
    DeletecartComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [CustomerService,ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
