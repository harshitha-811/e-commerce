import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../product.service';
import { Product } from '../entity/product';
import { CartService } from '../cart.service';
import { CustomerService } from '../customer.service';
import { Customer } from '../entity/customer';
import { CartComponent } from '../cart/cart.component';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {

  constructor(private activatedroute:ActivatedRoute, private productService:ProductService, private cartService:CartService, private customerService:CustomerService) { }

  customer:Customer;
  product:Product=new Product();
  ngOnInit(): void {
    let productId=this.activatedroute.snapshot.params['productId'];
    
    this.productService.getProduct(productId).subscribe(p=>this.product=p);
    localStorage.setItem('productId',productId);
    console.log(localStorage.getItem('productId'));
  }
  



}
