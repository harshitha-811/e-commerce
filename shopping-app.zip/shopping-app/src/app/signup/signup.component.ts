import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Customer } from '../entity/customer';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private customerService:CustomerService, private fb:FormBuilder,private router:Router) { }
  customerForm:FormGroup;
  customer:Customer=new Customer();
  message:string;

  ngOnInit(): void {
    this.initForm();
  }
  private initForm(){
    this.customerForm=this.fb.group({
      customerEmail:['',[Validators.required,Validators.pattern("^\\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$")]],
      customerPassword:['',[Validators.required,Validators.pattern("^(?=.*\\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$")]],
    });
  }
  onSubmit(){

    this.customer=this.customerForm.value;
    console.log(JSON.stringify(this.customer));
    this.customerService.signup(this.customer)
    .subscribe(m=>{
      this.message=m;
      this.router.navigate(['']);
    })
  }

}
